from neo4j import GraphDatabase
import pandas as pd
import time
import os
from tqdm import tqdm

# --- CONFIGURAZIONE ---
URI = "neo4j://127.0.0.1:7687"
AUTH = ("neo4j", "Giusbet1969!")
DB_NAME = "projectmedium"         
OUTPUT_FILE = "risultati_3a_MEDIUM.csv"
BATCH_SIZE = 500                  
# ----------------------

query_batch = """
MATCH (m:Customer)
WITH m ORDER BY m.customer_id SKIP $skip LIMIT $limit

MATCH (m)-[:PERFORMED]->(:Transaction)-[:OCCURRED_AT]->(t:Terminal)<-[:OCCURRED_AT]-(:Transaction)<-[:PERFORMED]-(n:Customer)
WHERE id(m) < id(n)

WITH m, n, count(DISTINCT t) AS shared_terminals
WHERE shared_terminals >= 4
AND m.tx_total IS NOT NULL AND n.tx_total IS NOT NULL
AND abs(m.tx_total - n.tx_total) <= 2

RETURN 
    m.customer_id AS Cliente_M, 
    n.customer_id AS Cliente_N, 
    shared_terminals AS Terminali_Condivisi, 
    m.tx_total AS Count_M, 
    n.tx_total AS Count_N
"""

print(f"🚀 AVVIO ANALISI SU {DB_NAME}...")
driver = GraphDatabase.driver(URI, auth=AUTH)

try:
    with driver.session(database=DB_NAME) as session:
        total_customers = session.run("MATCH (c:Customer) RETURN count(c) as tot").single()["tot"]
    
    if os.path.exists(OUTPUT_FILE):
        os.remove(OUTPUT_FILE)

    processed = 0
    start_time = time.time()

    with tqdm(total=total_customers, desc="Analisi Medium", unit="clienti") as pbar:
        while processed < total_customers:
            with driver.session(database=DB_NAME) as session:
                result = session.run(query_batch, skip=processed, limit=BATCH_SIZE).data()
            
            if result:
                df = pd.DataFrame(result)
                df.to_csv(OUTPUT_FILE, mode='a', header=(processed==0), index=False)
            
            processed += BATCH_SIZE
            pbar.update(BATCH_SIZE)

    total_time = time.time() - start_time
    print(f"\n✅ [MEDIUM] COMPLETATO in {total_time:.2f} secondi.")
    print(f"💾 File salvato: {OUTPUT_FILE}")

except Exception as e:
    print(f"❌ ERRORE: {e}")
finally:
    driver.close()