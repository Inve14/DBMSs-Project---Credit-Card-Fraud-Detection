from neo4j import GraphDatabase
import pandas as pd
import os
import calendar

# ==========================================
# CONFIGURAZIONE
# ==========================================
URI = "neo4j://127.0.0.1:7687"
AUTH = ("neo4j", "Giusbet1969!")

# --- SELEZIONA IL DATASET CORRETTO ---

# OPZIONE 1: SMALL
DB_NAME = "projectlarge"
OUTLIER_CSV = "query2_risultati/risultati_3b_LARGE.csv"

# OPZIONE 2: MEDIUM
# DB_NAME = "projectmedium"
# OUTLIER_CSV = "risultati_3b_MEDIUM.csv"

# OPZIONE 3: LARGE
# DB_NAME = "projectlarge"
# OUTLIER_CSV = "risultati_3b_LARGE.csv"
# ==========================================

def get_day_name(day_index):
    # Neo4j dayOfWeek: 1=Mon, 7=Sun
    # Python calendar: 0=Mon, 6=Sun
    days = ["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"]
    return days[day_index - 1]

def analyze_weekly_stats():
    print(f"📅 ANALISI SETTIMANALE TRANSAZIONI E OUTLIER SU: {DB_NAME}")
    print("-" * 60)

    # 1. Carichiamo gli OUTLIER dal file CSV (generato al punto 3.b)
    if not os.path.exists(OUTLIER_CSV):
        print(f"❌ ERRORE: Non trovo il file {OUTLIER_CSV}!")
        print("   Devi prima eseguire lo script del punto 3.b per trovare gli outlier.")
        return

    print("   📂 Lettura dati Outlier dal CSV...")
    df_outliers = pd.read_csv(OUTLIER_CSV)
    
    # Convertiamo la colonna 'Data' in datetime per estrarre il giorno
    df_outliers['Data'] = pd.to_datetime(df_outliers['Data'])
    
    # Estraiamo il giorno della settimana (Neo4j usa 1=Lunedì, Pandas usa 0=Lunedì. Adattiamo a Neo4j)
    df_outliers['Day_Index'] = df_outliers['Data'].dt.dayofweek + 1
    
    # Contiamo gli outlier per giorno
    outlier_counts = df_outliers.groupby('Day_Index').size().reset_index(name='Num_Outliers')
    
    print(f"   ✅ Caricati {len(df_outliers)} outlier totali.")

    # 2. Chiediamo a Neo4j il TOTALE transazioni per giorno della settimana
    print("   🔌 Interrogazione Neo4j per i totali giornalieri...")
    driver = GraphDatabase.driver(URI, auth=AUTH)
    
    # Usiamo tx.datetime.dayOfWeek (Restituisce 1 per Lunedì, 7 per Domenica)
    query_total = """
    MATCH (tx:Transaction)
    RETURN tx.datetime.dayOfWeek as Day_Index, count(tx) as Total_Tx
    ORDER BY Day_Index
    """
    
    try:
        with driver.session(database=DB_NAME) as session:
            result = session.run(query_total).data()
            df_totals = pd.DataFrame(result)
            
    except Exception as e:
        print(f"❌ Errore Neo4j: {e}")
        return
    finally:
        driver.close()

    # 3. MERGE E CALCOLO PERCENTUALI
    # Uniamo la tabella dei totali con quella degli outlier usando 'Day_Index'
    df_final = pd.merge(df_totals, outlier_counts, on='Day_Index', how='left')
    
    # Sostituiamo i NaN (giorni senza outlier) con 0
    df_final['Num_Outliers'] = df_final['Num_Outliers'].fillna(0).astype(int)
    
    # Calcolo Percentuale
    df_final['Percentuale_Outlier'] = (df_final['Num_Outliers'] / df_final['Total_Tx']) * 100
    
    # Aggiungiamo il nome del giorno
    df_final['Giorno'] = df_final['Day_Index'].apply(get_day_name)
    
    # Riordiniamo le colonne
    df_final = df_final[['Giorno', 'Total_Tx', 'Num_Outliers', 'Percentuale_Outlier']]

    # ==========================================
    # STAMPA RISULTATI
    # ==========================================
    print("\n" + "="*65)
    print(f"📊 REPORT SETTIMANALE: {DB_NAME}")
    print("="*65)
    
    # Formattiamo la tabella per renderla leggibile
    print(df_final.to_string(index=False, formatters={
        'Percentuale_Outlier': '{:.4f}%'.format,
        'Total_Tx': '{:,}'.format,
        'Num_Outliers': '{:,}'.format
    }))
    print("="*65)
    
    # Salvataggio su file
    out_filename = f"report_settimanale_{DB_NAME}.csv"
    df_final.to_csv(out_filename, index=False)
    print(f"\n💾 Tabella salvata in: {out_filename}")

if __name__ == "__main__":
    analyze_weekly_stats()