from neo4j import GraphDatabase
import time
from tqdm import tqdm

# ==========================================
# CONFIGURAZIONE
# ==========================================
URI = "neo4j://127.0.0.1:7687"
AUTH = ("neo4j", "Giusbet1969!")

# CAMBIA IL DATABASE QUI (projectsmall / projectmedium / projectlarge)
DB_NAME = "projectlarge" 
BATCH_SIZE = 100  # Analizziamo 100 Terminali alla volta
# ==========================================

# Query Intelligente:
# Parte dal Terminale (t) e guarda solo chi ha la relazione HEAVY_VISITOR
query_collaborators = """
MATCH (t:Terminal)
WHERE t.terminal_id IN $terminal_ids

// Trova coppie di Heavy Visitors su questo terminale
MATCH (c1:Customer)-[:HEAVY_VISITOR]->(t)<-[:HEAVY_VISITOR]-(c2:Customer)
WHERE id(c1) < id(c2) // Evita duplicati (A-B e B-A)

// Filtro sulla soddisfazione (Sfrutta il valore pre-calcolato!)
AND c1.avg_satisfaction IS NOT NULL 
AND c2.avg_satisfaction IS NOT NULL
AND abs(c1.avg_satisfaction - c2.avg_satisfaction) <= 0.5

// Crea la relazione richiesta
MERGE (c1)-[r:FREQUENT_COLLABORATOR]->(c2)
ON CREATE SET r.connected_via_terminal = t.terminal_id
"""

def create_collaborators():
    print(f"🤝 CREAZIONE COLLABORATORI FREQUENTI SU: {DB_NAME}")
    print("   Criteri: Stesso terminale (>=5 tx) AND Media Voto simile (diff <= 0.5)")
    print("-" * 50)
    
    driver = GraphDatabase.driver(URI, auth=AUTH)
    
    try:
        # 1. Recuperiamo la lista dei Terminali "Attivi"
        # (Quelli che hanno almeno 2 Heavy Visitors, altrimenti non ci sono coppie da formare)
        print("🔍 Cerco terminali con almeno 2 visitatori frequenti...")
        with driver.session(database=DB_NAME) as session:
            q_terminals = """
            MATCH (t:Terminal)<-[:HEAVY_VISITOR]-(c:Customer)
            WITH t, count(c) as visitors
            WHERE visitors >= 2
            RETURN t.terminal_id as id
            """
            result = session.run(q_terminals).data()
            terminal_ids = [r['id'] for r in result]
        
        print(f"✅ Trovati {len(terminal_ids)} terminali dove potrebbero esserci collaborazioni.")
        
        if len(terminal_ids) == 0:
            print("⚠️ Nessun terminale soddisfa i requisiti (forse nessuno ha >= 5 tx?).")
            return

        # 2. Ciclo Batch sui Terminali
        start_time = time.time()
        chunks = [terminal_ids[i:i + BATCH_SIZE] for i in range(0, len(terminal_ids), BATCH_SIZE)]
        
        with tqdm(total=len(terminal_ids), desc="Analisi Terminali", unit="term") as pbar:
            for chunk in chunks:
                with driver.session(database=DB_NAME) as session:
                    session.run(query_collaborators, terminal_ids=chunk)
                pbar.update(len(chunk))

        total_time = time.time() - start_time
        print("-" * 50)
        print(f"🎉 RELAZIONI CREATE IN {total_time:.2f} SECONDI.")
        
    except Exception as e:
        print(f"❌ ERRORE: {e}")
        print("SUGGERIMENTO: Hai eseguito le FASI 1 e 2 su Neo4j Browser prima?")
    finally:
        driver.close()

if __name__ == "__main__":
    create_collaborators()