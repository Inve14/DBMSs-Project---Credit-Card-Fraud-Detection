from neo4j import GraphDatabase
import pandas as pd
import time
import os
from tqdm import tqdm

# --- CONFIGURAZIONE ---
URI = "neo4j://127.0.0.1:7687"
AUTH = ("neo4j", "Giusbet1969!")
DB_NAME = "projectlarge"          
OUTPUT_FILE = "network_CC3_names_LARGE.csv"
BATCH_SIZE = 25   # Batch molto piccolo per evitare crash di memoria
# ----------------------

query_cc3_names = """
MATCH (u1:Customer)
WITH u1 ORDER BY u1.customer_id SKIP $skip LIMIT $limit

MATCH (u1)-[:USED]->(t1:Terminal)<-[:USED]-(u2:Customer)
WHERE u2 <> u1

MATCH (u2)-[:USED]->(t2:Terminal)<-[:USED]-(u3:Customer)
WHERE u3 <> u2 AND u3 <> u1

RETURN 
    u1.customer_id AS Cliente_Target,
    count(DISTINCT u3) as Network_Size,
    collect(DISTINCT u3.customer_id) as Co_Customer_List
"""

print(f"🚀 AVVIO ANALISI RETE (CON NOMI) SU {DB_NAME}...")
driver = GraphDatabase.driver(URI, auth=AUTH)

try:
    with driver.session(database=DB_NAME) as session:
        total = session.run("MATCH (c:Customer) RETURN count(c) as tot").single()["tot"]
    print(f"👥 Totale Utenti: {total}")
    
    if os.path.exists(OUTPUT_FILE):
        os.remove(OUTPUT_FILE)

    processed = 0
    start_time = time.time()

    with tqdm(total=total, desc="Estraendo Nomi", unit="utenti") as pbar:
        while processed < total:
            with driver.session(database=DB_NAME) as session:
                result = session.run(query_cc3_names, skip=processed, limit=BATCH_SIZE).data()
            
            if result:
                df = pd.DataFrame(result)
                df.to_csv(OUTPUT_FILE, mode='a', header=(processed==0), index=False)
            
            processed += BATCH_SIZE
            pbar.update(BATCH_SIZE)

    total_time = time.time() - start_time
    print(f"\n✅ [LARGE] COMPLETATO in {total_time:.2f} secondi.")
    print(f"💾 File salvato: {OUTPUT_FILE}")

except Exception as e:
    print(f"❌ ERRORE: {e}")
finally:
    driver.close()