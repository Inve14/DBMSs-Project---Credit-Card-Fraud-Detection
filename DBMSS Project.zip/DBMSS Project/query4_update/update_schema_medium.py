from neo4j import GraphDatabase
import random
from tqdm import tqdm
import time

# ==========================================
# CONFIGURAZIONE
# ==========================================
URI = "neo4j://127.0.0.1:7687"
AUTH = ("neo4j", "Giusbet1969!")

# CAMBIA QUI IL DATABASE: projectsmall / projectmedium / projectlarge
DB_NAME = "projectmedium" 

BATCH_SIZE = 5000  # Aggiorniamo 5000 transazioni alla volta
# ==========================================

# Opzioni per i dati casuali
PAYMENT_METHODS = ["Credit Card", "Debit Card", "Mobile Payment", "PayPal", "Bank Transfer"]
PROMO_OPTIONS = [True, False] # True = Sì, False = No
SATISFACTION_RANGE = [1, 2, 3, 4, 5]

# Query di aggiornamento massivo (UNWIND è velocissimo)
update_query = """
UNWIND $batch_data AS row
MATCH (t:Transaction {transaction_id: row.id})
SET t.payment_method = row.method,
    t.is_promo = row.promo,
    t.satisfaction_score = row.score
"""

def extend_schema():
    print(f"🛠️  ESTENSIONE SCHEMA SU: {DB_NAME}")
    print(f"    Aggiunta: Payment Method, Promo, Satisfaction Score")
    print("-" * 50)
    
    driver = GraphDatabase.driver(URI, auth=AUTH)
    
    try:
        # 1. Recuperiamo TUTTI gli ID delle transazioni
        print("⏳ Recupero lista ID transazioni (questo potrebbe richiedere un attimo)...")
        with driver.session(database=DB_NAME) as session:
            result = session.run("MATCH (t:Transaction) RETURN t.transaction_id AS id").data()
            all_ids = [r['id'] for r in result]
        
        total_tx = len(all_ids)
        print(f"✅ Trovate {total_tx} transazioni da aggiornare.")
        
        # 2. Ciclo di aggiornamento a blocchi
        start_time = time.time()
        
        # Creiamo i batch (pacchetti da 5000)
        # Slicing della lista: all_ids[i : i + BATCH_SIZE]
        chunks = [all_ids[i:i + BATCH_SIZE] for i in range(0, len(all_ids), BATCH_SIZE)]
        
        with tqdm(total=total_tx, desc="Aggiornamento Dati", unit="tx") as pbar:
            for chunk_ids in chunks:
                
                # Generiamo i dati casuali per questo blocco
                batch_data = []
                for tx_id in chunk_ids:
                    batch_data.append({
                        "id": tx_id,
                        "method": random.choice(PAYMENT_METHODS),
                        # Diamo il 20% di probabilità che sia una promo (più realistico del 50/50)
                        "promo": random.choices(PROMO_OPTIONS, weights=[20, 80])[0], 
                        "score": random.choice(SATISFACTION_RANGE)
                    })
                
                # Eseguiamo l'aggiornamento su Neo4j
                with driver.session(database=DB_NAME) as session:
                    session.run(update_query, batch_data=batch_data)
                
                pbar.update(len(chunk_ids))

        total_time = time.time() - start_time
        print("-" * 50)
        print(f"🎉 AGGIORNAMENTO COMPLETATO in {total_time:.2f} secondi!")
        
    except Exception as e:
        print(f"❌ ERRORE: {e}")
    finally:
        driver.close()

if __name__ == "__main__":
    extend_schema()