# Project Documentation: Fraud Detection in Payment Operations

## 1. Technical Documentation

### a. UML Class Diagram

The following UML Class Diagram represents the structure of the entities involved in the fraud detection system.

```mermaid
classDiagram
    class Customer {
        +String customer_id
        +Float x
        +Float y
        +Float mean_amount
        +Float std_amount
        +Float mean_nb_tx
        +Int nb_terminals
        +Float avg_satisfaction
    }

    class Terminal {
        +String terminal_id
        +Float x
        +Float y
        +Float median_prev_q
    }

    class Transaction {
        +String transaction_id
        +Float amount
        +DateTime datetime
        +Boolean is_fraud
        +Int fraud_scenario
        +String payment_method
        +Boolean is_promo
        +Int satisfaction_score
    }

    Customer "1" --> "0..*" Transaction : PERFORMS
    Transaction "0..*" --> "1" Terminal : OCCURRED_AT
    Customer "0..*" --> "0..*" Terminal : HEAVY_VISITOR
    Customer "0..*" --> "0..*" Customer : FREQUENT_COLLABORATOR
```

**Design Decisions & Constraints:**
- **Customer**: Represents the cardholder. Properties include geographical coordinates (`x`, `y`) and behavioral statistics (`mean_amount`, `std_amount`) used for generating transactions. `avg_satisfaction` is added during schema updates for advanced analysis.
- **Terminal**: Represents the point of sale. `median_prev_q` is a pre-calculated property (Optimization Pattern) used for outlier detection (Query 2).
- **Transaction**: Central entity linking customers and terminals. It stores the core payment data. Properties like `payment_method` and `satisfaction_score` are added dynamically (Schema Evolution).
- **Relationships**:
    - `PERFORMED`: Direct link from Customer to Transaction.
    - `OCCURRED_AT`: Direct link from Transaction to Terminal.
    - `HEAVY_VISITOR` & `FREQUENT_COLLABORATOR`: Derived relationships created by analytical queries (Query 4) to model complex behavioral patterns.

### b. Logical Data Model

The logical model chosen for this project is a **Property Graph Model**, implemented using **Neo4j**.

**Nodes (Entities):**
1.  **Customer (~20k nodes in Large)**: Labeled `:Customer`. Unique Constraint on `customer_id`.
2.  **Terminal (~2k nodes in Large)**: Labeled `:Terminal`. Unique Constraint on `terminal_id`.
3.  **Transaction (~5.8M nodes in Large)**: Labeled `:Transaction`. Unique Constraint on `transaction_id`. Indexed on `tx_datetime` for temporal filtering.

**Relationships (Edges):**
*   `(:Customer)-[:PERFORMED]->(:Transaction)`
*   `(:Transaction)-[:OCCURRED_AT]->(:Terminal)`
*   `(:Customer)-[:HEAVY_VISITOR]->(:Terminal)` (Derived)
*   `(:Customer)-[:FREQUENT_COLLABORATOR {connected_via_terminal: ID}]->(:Customer)` (Derived)

**Motivation for Graph Model:**
1.  **Relationship-Centric Analysis**: Fraud detection often involves finding rings or networks (e.g., "Friend of Friend" in Query 3, or shared terminals in Query 1). Graph databases optimize traversal performance ($O(1)$ per hop) compared to relational JOINs ($O(logN)$ or worse).
2.  **Schema Flexibility**: The requirement to update the schema (Query 4) by adding new properties and relationships to existing nodes is handled natively by Neo4j without table locking or costly `ALTER TABLE` operations.
3.  **Pattern Matching**: Cypher query language allows expressing complex fraud patterns (e.g., "Customer A and Customer B share 4 terminals") concisely.

### c. Data Loading Script

The loading process is managed by the `FraudLoader` class (Python/Neo4j Driver).

**Key Steps:**
1.  **Constraint Creation**: Before loading, unique constraints are applied to `customer_id`, `terminal_id`, and `transaction_id`. An index is created on `Transaction(datetime)` to speed up temporal range queries (crucial for Query 2 and 5).
2.  **Batch Processing**: Data is read from Pandas DataFrames (`.pkl` files).
3.  **UNWIND Optimization**: Instead of running one `CREATE` statement per row, the script passes batches of rows (e.g., 2000 customers or 1000 transactions) as a parameter (`$rows`). The Cypher `UNWIND` clause expands this list, allowing Neo4j to process thousands of insertions in a single transaction log commit. This significantly reduces I/O overhead.
4.  **Temporal Conversion**: Transaction dates strings are converted to Neo4j `DateTime` objects during import.

### d. Implementation of Operations

#### Query 1: Fraud Ring Detection (Shared Terminals)
*   **Goal**: Identify pairs of customers who share at least 4 terminals and have a similar total transaction count (difference $\le$ 2).
*   **Implementation**:
    *   Matches patterns `(c1)-[:PERFORMED]->(:Tx)-[:OCCURRED_AT]->(t)<-[:OCCURRED_AT]-(:Tx)<-[:PERFORMED]-(c2)`.
    *   Uses `count(DISTINCT t)` to filter pairs with $\ge 4$ shared terminals.
    *   Validates transaction count similarity using pre-calculated `tx_total` properties (Optimization).

#### Query 2: Potential Outlier Detection
*   **Goal**: Find transactions in the current quarter (July-Sept) that exceed the previous quarter's median amount by 30%.
*   **Implementation**:
    *   Filters `Transaction` nodes by `datetime` (using the Index).
    *   Matches `(tx)-[:OCCURRED_AT]->(t)`.
    *   Compares `tx.amount` with `t.median_prev_q` (an optimized property stored on the Terminal node to avoid re-calculating the median every time).

#### Query 3: Network Analysis (Topology Degree 3)
*   **Goal**: For each customer, identify the size of their "3-hop" network (User -> Terminal -> User -> Terminal -> User).
*   **Implementation**:
    *   Traverses the path `(u1)-[:USED]->(t1)<-[:USED]-(u2)-[:USED]->(t2)<-[:USED]-(u3)`.
    *   Collects distinct `u3` customers.
    *   This simulates a "Friend of Friend" recommendation or risk propagation network.

#### Query 4: Schema Evolution & Collaborators
*   **Part A (Schema Update)**: Adds `payment_method`, `is_promo`, and `satisfaction_score` to Transaction nodes. Uses `UNWIND` for massive updates.
*   **Part B (Collaboration Graph)**:
    *   Identifies "Heavy Visitors" (customers with many tx at a terminal).
    *   Creates a new relationship `FREQUENT_COLLABORATOR` between customers who frequent the same terminal and have similar satisfaction scores (`abs(score1 - score2) <= 0.5`).
    *   This transforms the graph from a simple bipartite (User-Terminal) structure into a social-like monopartite graph (User-User).

#### Query 5: Weekly Statistics
*   **Goal**: Compare total transaction volume vs. outliers found (from Query 2) per day of the week.
*   **Implementation**:
    *   Aggregates Neo4j data using `datetime.dayOfWeek`.
    *   Merges graph data with CSV results from Query 2 using Pandas.
    *   Produces a report showing the percentage of suspicious activity per day (e.g., "Monday: 0.45% outliers").

### e. Performance Discussion

The experiments were conducted on three datasets (Small, Medium, Large).

**Performance Patterns:**
1.  **Linear Scaling with Indexing**: Operations like Query 2 (Outliers) scale relatively linearly with dataset size because the `tx_datetime` index prevents full-table scans. Without the index, performance on the Large dataset (5.8M transactions) would degrade significantly.
2.  **Complexity of Network Queries**: Query 3 (3-hop network) creates a massive combinatorial explosion on the Large dataset. The number of paths grows exponentially with the network density.
3.  **Batching efficacy**: The data loading and Schema Update (Query 4) utilize `batch_size=1000-5000`. This kept memory usage stable even for the Large dataset.

**Optimization Patterns Applied:**
-   **Pre-calculation (`median_prev_q`, `tx_total`)**: Instead of computing aggregates on the fly during complex queries, values were pre-calculated and stored as node properties. This reduced Query 1 and Query 2 execution times from minutes to seconds.
-   **Indexing**: `CREATE INDEX ON :Transaction(datetime)` was critical for temporal filtering.
-   **Projection (Implicit)**: Queries were designed to match patterns strictly necessary (e.g., `WITH` clauses to drop unused variables) to reduce memory pressure.

**(Please insert here the graphs comparing execution times for Small, Medium, and Large datasets, based on your local run logs).**

## 2. Reproducing Experiments

To reproduce the study, follow these steps:

1.  **Prerequisites**:
    *   Neo4j Desktop/Server running on `localhost:7687` (Auth: `neo4j`/`Giusbet1969!`).
    *   Python 3.9+ with `neo4j`, `pandas`, `tqdm`, `matplotlib` installed.
    *   Dataset pickle files (`customers.pkl`, etc.) placed in `Project_Dataset_*` folders.

2.  **Execution Order**:
    *   **Loading**: Run `work.ipynb` (Loading section) or extract the loading code to `load_data.py` to populate `projectsmall`, `projectmedium`, `projectlarge` databases sequentially.
    *   **Preprocessing**: Ensure `tx_total` and `median_prev_q` properties are set (using preliminary Cypher scripts provided in the notebooks).
    *   **Queries**:
        *   Run `python query1/query1_*.py`
        *   Run `python query2/query2_*.py`
        *   Run `python query3/query3_*.py`
        *   Run `python query4_update/update_schema_*.py`
        *   Run `python query4_frequency_collaborator/query4_collaborators_*.py`
        *   Run `python query5/query5_weekly_stats_*.py`

3.  **Outputs**:
    *   CSVs are generated in the root or respective folders.
    *   Logs in the console display execution times.
