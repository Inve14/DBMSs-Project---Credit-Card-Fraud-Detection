from neo4j import GraphDatabase
import pandas as pd
import time
import os
from tqdm import tqdm

# --- CONFIGURAZIONE ---
URI = "neo4j://127.0.0.1:7687"
AUTH = ("neo4j", "Giusbet1969!")
DB_NAME = "projectlarge"          
OUTPUT_FILE = "risultati_3b_LARGE.csv"
BATCH_SIZE = 1000                 
# ----------------------

query_batch = """
MATCH (t:Terminal)
// Prendiamo solo i terminali che hanno una mediana storica calcolata
WHERE t.median_prev_q IS NOT NULL
WITH t ORDER BY t.terminal_id SKIP $skip LIMIT $limit

// Cerchiamo transazioni del Trimestre Corrente (Lug-Ago-Set)
MATCH (tx:Transaction)-[:OCCURRED_AT]->(t)
WHERE tx.datetime >= datetime('2018-07-01T00:00:00') 
  AND tx.datetime < datetime('2018-10-01T00:00:00')

// --- LOGICA OUTLIER ---
// L'importo deve essere > della Mediana precedente + 30% (cioè * 1.30)
AND tx.amount > (t.median_prev_q * 1.30)

RETURN 
    t.terminal_id AS Terminal_ID,
    t.median_prev_q AS Mediana_Trimestre_Prec,
    tx.transaction_id AS Tx_Outlier_ID,
    tx.amount AS Importo_Sospetto,
    tx.datetime AS Data,
    "Potential Outlier" AS Label
"""

print(f"🚀 AVVIO ANALISI OUTLIER SU {DB_NAME}...")
driver = GraphDatabase.driver(URI, auth=AUTH)

try:
    # Contiamo su quanti terminali dobbiamo lavorare
    with driver.session(database=DB_NAME) as session:
        count_query = "MATCH (t:Terminal) WHERE t.median_prev_q IS NOT NULL RETURN count(t) as tot"
        total_terminals = session.run(count_query).single()["tot"]
    
    print(f"🏢 Terminali con storico da analizzare: {total_terminals}")
    
    if os.path.exists(OUTPUT_FILE):
        os.remove(OUTPUT_FILE)

    processed = 0
    start_time = time.time()
    outliers_found = 0

    with tqdm(total=total_terminals, desc="Analisi Outlier Small", unit="terminali") as pbar:
        while processed < total_terminals:
            
            with driver.session(database=DB_NAME) as session:
                result = session.run(query_batch, skip=processed, limit=BATCH_SIZE).data()
            
            if result:
                df = pd.DataFrame(result)
                df.to_csv(OUTPUT_FILE, mode='a', header=(processed==0), index=False)
                outliers_found += len(result)
            
            processed += BATCH_SIZE
            pbar.update(BATCH_SIZE)

    total_time = time.time() - start_time
    print(f"\n✅ [SMALL] COMPLETATO in {total_time:.2f} secondi.")
    print(f"⚠️ Trovati {outliers_found} potenziali outlier.")
    print(f"💾 File salvato: {OUTPUT_FILE}")

except Exception as e:
    print(f"❌ ERRORE: {e}")
    print("Suggerimento: Hai eseguito la FASE 1 su Neo4j (SET t.median_prev_q)?")
finally:
    driver.close()